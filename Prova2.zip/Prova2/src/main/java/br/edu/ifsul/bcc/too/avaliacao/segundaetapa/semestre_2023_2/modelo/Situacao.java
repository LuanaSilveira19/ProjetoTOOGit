
package br.edu.ifsul.bcc.too.avaliacao.segundaetapa.semestre_2023_2.modelo;


public enum Situacao {
    VIVO, ABATIDO, VENDIDO, MORTO
}
