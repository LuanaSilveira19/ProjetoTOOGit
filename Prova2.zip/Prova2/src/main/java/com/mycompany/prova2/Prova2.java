/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prova2;

/**
 *
 * @author Luana
 */
public class Prova2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
