
package br.edu.ifsul.bcc.too.reavaliacao.semestre_2023_2.modelo;


public enum Situacao {
    VIVO, ABATIDO, VENDIDO, MORTO
}
