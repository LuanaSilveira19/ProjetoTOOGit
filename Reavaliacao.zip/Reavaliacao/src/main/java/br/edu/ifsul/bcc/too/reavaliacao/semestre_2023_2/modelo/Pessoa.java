
package br.edu.ifsul.bcc.too.reavaliacao.semestre_2023_2.modelo;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public abstract class Pessoa {
    private String cpf;
    private String rg;
    private String nome;
    private Calendar data_nascimento;
    private String cep;
    private String numero;
    private String complemento;

    public Pessoa() {
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Calendar getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(Calendar data_nascimento) {
        this.data_nascimento = data_nascimento;
    }
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    public String setData_nascimento_string(String data_nascimento) {
         try {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(sdf.parse(data_nascimento).getTime());
            this.data_nascimento = c;
        } catch (Exception e) {
            this.data_nascimento = null;
        }

           return null;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }
    
    
}
